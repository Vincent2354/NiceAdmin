<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>London: Capital of England</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1 class="display-4 text-primary">London</h1>
        <p class="lead">London is the **capital city of England** and the most populous city in the United Kingdom, featuring a vast metropolitan area with over 13 million inhabitants.</p>
        <p>Standing prominently on the River Thames, London has been a major settlement for two millennia. Its rich history originates from its founding by the Romans, who originally christened it **Londinium**.</p>
    </div>
</body>
</html>