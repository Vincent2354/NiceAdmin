<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tokyo: Global Megacity</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1 class="display-4 text-primary">Tokyo</h1>
        <p class="lead">Tokyo is the **capital city of Japan** and is recognized as the most populous metropolitan area in the world, serving as the central hub of Japanese politics and economy.</p>
        <p>Tokyo has held the distinction of being Japan's capital since 1869. It is internationally renowned for its seamless integration of **modernity, deep cultural heritage, and cutting-edge technology**.</p>
    </div>
</body>
</html>