<h5 class="card-title">User Registration</h5>

<form class="row g-3 needs-validation" novalidate>
  <div class="col-md-12">
    <div class="form-floating">
      <input type="text" class="form-control" id="floatingName" placeholder="Your Name" required>
      <label for="floatingName">Full Name</label>
      <div class="invalid-feedback">Please enter your full name.</div>
    </div>
  </div>

  <div class="col-md-6">
    <div class="form-floating">
      <input type="email" class="form-control" id="floatingEmail" placeholder="Your Email" required>
      <label for="floatingEmail">Email Address</label>
      <div class="invalid-feedback">Please enter a valid email address.</div>
    </div>
  </div>

  <div class="col-md-6">
    <div class="form-floating">
      <input type="password" class="form-control" id="floatingPassword" placeholder="Password" required pattern=".{8,}" title="Password must be at least 8 characters long">
      <label for="floatingPassword">Password (min 8 characters)</label>
      <div class="invalid-feedback">Please enter a valid password (min 8 characters).</div>
    </div>
  </div>

  <div class="col-12">
    <div class="form-floating">
      <input type="text" class="form-control" id="floatingAddress1" placeholder="Address Line 1" required>
      <label for="floatingAddress1">Address Line 1</label>
      <div class="invalid-feedback">Please enter your address.</div>
    </div>
  </div>

  <div class="col-12">
    <div class="form-floating">
      <input type="text" class="form-control" id="floatingAddress2" placeholder="Address Line 2 (Optional)">
      <label for="floatingAddress2">Address Line 2 (Optional)</label>
    </div>
  </div>

  <div class="col-md-6">
    <div class="form-floating">
      <input type="text" class="form-control" id="floatingCity" placeholder="City / Town" required>
      <label for="floatingCity">City / Town</label>
      <div class="invalid-feedback">Please enter your city or town.</div>
    </div>
  </div>

  <div class="col-md-4">
    <div class="form-floating mb-3">
      <select class="form-select" id="floatingSelect" aria-label="Region" required>
        <option selected disabled value="">Choose your Region/Country</option>
        <option value="London">Greater London</option>
        <option value="Manchester">Greater Manchester</option>
        <option value="Scotland">Scotland</option>
        <option value="Wales">Wales</option>
      </select>
      <label for="floatingSelect">Region / Country</label>
      <div class="invalid-feedback">Please select your region or country.</div>
    </div>
  </div>

  <div class="col-md-2">
    <div class="form-floating">
      <input type="text" class="form-control" id="floatingPostcode" placeholder="Postcode" required pattern="[A-Za-z0-9\s]{5,10}" title="Please enter a valid UK Postcode (e.g., SW1A 0AA)">
      <label for="floatingPostcode">Postcode</label>
      <div class="invalid-feedback">Please enter a valid UK Postcode.</div>
    </div>
  </div>

  <div class="col-12">
    <div class="form-check">
      <input class="form-check-input" type="checkbox" value="" id="termsCheck" required>
      <label class="form-check-label" for="termsCheck">
        I agree to the <a href="#" data-bs-toggle="tooltip" title="Read the terms and conditions">terms and conditions</a> and the privacy policy.
      </label>
      <div class="invalid-feedback">You must agree to the terms and conditions to proceed.</div>
    </div>
  </div>

  <div class="text-center">
    <button type="submit" class="btn btn-primary">Register Account</button>
    <button type="reset" class="btn btn-secondary">Clear Form</button>
  </div>
</form><script>
  // Enable tooltips for terms and conditions
  var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
  tooltipTriggerList.map(function (tooltipTriggerEl) {
    return new bootstrap.Tooltip(tooltipTriggerEl);
  });

  // Form Validation
  (function () {
    'use strict'
    var forms = document.querySelectorAll('.needs-validation')
    Array.prototype.slice.call(forms)
      .forEach(function (form) {
        form.addEventListener('submit', function (event) {
          if (!form.checkValidity()) {
            event.preventDefault()
            event.stopPropagation()
          }
          form.classList.add('was-validated')
        }, false)
      })
  })()
</script>