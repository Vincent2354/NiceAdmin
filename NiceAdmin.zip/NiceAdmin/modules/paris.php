<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Paris: The City of Lights</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1 class="display-4 text-primary">Paris</h1>
        <p class="lead">Paris is the **capital city of France**, affectionately known globally for its unparalleled contributions to art, high fashion, world-class gastronomy, and rich culture.</p>
        <p>As a global city, Paris has been a major center of finance, diplomacy, commerce, fashion, science, and the arts since the **17th century**, establishing its historical importance and influence.</p>
    </div>
</body>
</html>